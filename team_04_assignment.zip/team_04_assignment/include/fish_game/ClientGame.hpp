#pragma once

#include "AssetManager.hpp"
#include "ECS/ComponentsGenerator.hpp"
#include "Map.hpp"
#include "NetworkClient.hpp"

#include <SDL2/SDL.h>
#include <stdio.h>
#include <string>
#include <vector>

namespace FishEngine {
constexpr int SCREEN_WIDTH = 2048;
constexpr int SCREEN_HEIGHT = 1024;

enum groupLabels : std::size_t;

class ClientGame {

  public:
	static ClientGame &getInstance() {
		static ClientGame instance; // Guaranteed to be destroyed and instantiated on first use
		return instance;
	}

	SDL_Event getEvent() const { return game_event; }

	void init(fs::path mp, bool combat);

	void reset();

	void loadFishSprites();

	void handleEvents();

	void update();

	void render() const;

	void createHostPlayer();

	void showIP(SDL_Texture *mTexture, int width, int height);

	uint8_t updateMainMenu() const;

	std::string joinInterface();

	void sendJoinRequest(std::string ip, std::string username);

	void receiveGameState();

	bool running() const;

	void stop();

	void zoomIn();

	void removeEntity(uint8_t id) { entityGroups.erase(id); }

	void startLoadingBar();

	void renderLoadingBar();

	void printEntityMetaData();

	Manager *getManager();

	inline static SDL_Renderer *renderer = nullptr;
	inline static SDL_Event game_event;
	inline static AssetManager *assets;
	inline static SDL_Rect camera;

	NetworkClient networkClient;

	uint8_t hostPlayerID;

  private:
	// Singelton
	ClientGame();
	ClientGame(const ClientGame &) = delete;
	ClientGame &operator=(const ClientGame &) = delete;
	~ClientGame();

	bool initialized;

	Manager manager;
	Entity *hostPlayer;
	std::unordered_map<uint8_t, groupLabels> entityGroups;
	int numPlayers = 6;
	bool isRunning = false;
	bool connected = false;

	Map *map = nullptr;
	fs::path mapPath;

	SDL_Window *window;
	bool windowed = false;

	const char *title;
	int xpos = SDL_WINDOWPOS_CENTERED;
	int ypos = SDL_WINDOWPOS_CENTERED;
	int width = SCREEN_WIDTH;
	int height = SCREEN_HEIGHT;
	bool fullscreen = true;

	// increment this for each new fish sprite and reset at init
	size_t fishSpriteID = 0;
	size_t progressUpdate = 0;
};

} // namespace FishEngine
