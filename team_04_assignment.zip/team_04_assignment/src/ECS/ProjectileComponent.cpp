#include "../../include/fish_game/ECS/ProjectileComponent.hpp"

#include "../../include/fish_game/ClientGame.hpp"
#include "../../include/fish_game/Vector2D.hpp"

#include "spdlog/spdlog.h"

namespace FishEngine {

ProjectileComponent::ProjectileComponent(int rng, int sp, Vector2D vel) : range(rng), speed(sp), velocity(vel) {}

ProjectileComponent::~ProjectileComponent() {
	// spdlog::get("console")->info("ProjectileComponent - destructor - entity ID: {}", entity->getID());
}

void ProjectileComponent::init() {
	spdlog::get("console")->info("ProjectileComponent - init - entity ID: {}", entity->getID());
	transform = &entity->getComponent<TransformComponent>();
}

void ProjectileComponent::update() {
	transform->setVelocity(velocity * (transform->isFacingRight() ? 1.0 : -1.0));
	distance += speed;

	if (distance > range) {
		spdlog::get("console")->debug("Projectile out of range");
		// entity->destroy();
	}
}

} // namespace FishEngine

#include <cereal/archives/json.hpp>
#include <cereal/types/polymorphic.hpp>

CEREAL_REGISTER_TYPE(FishEngine::ProjectileComponent);