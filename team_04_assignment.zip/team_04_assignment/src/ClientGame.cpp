#include "../include/fish_game/ClientGame.hpp"
#include "../include/fish_game/AssetManager.hpp"
#include "../include/fish_game/Auxiliary.hpp"
#include "../include/fish_game/Collision.hpp"
#include "../include/fish_game/ECS/ColliderComponent.hpp"
#include "../include/fish_game/ECS/ComponentsGenerator.hpp"
#include "../include/fish_game/ECS/MoveComponent.hpp"
#include "../include/fish_game/ECS/SpriteComponent.hpp"
#include "../include/fish_game/ECS/TransformComponent.hpp"
#include "../include/fish_game/ECS/WearableComponent.hpp"
#include "../include/fish_game/FontManager.hpp"
#include "../include/fish_game/Map.hpp"
#include "../include/fish_game/TextureManager.hpp"
#include "../include/fish_game/Vector2D.hpp"

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>
#include <cereal/archives/binary.hpp>
#include <fstream>
#include <future>
#include <iostream>
#include <spdlog/spdlog.h>

namespace FishEngine {

// ================== helper functions ==================
// @author: Leopold Schmid
void toggleWindowMode(SDL_Window *win, bool *windowed) {
	// Grab the mouse so that we don't end up with unexpected movement when the dimensions/position of the window
	// changes.
	SDL_SetRelativeMouseMode(SDL_TRUE);
	*windowed = !*windowed;
	if (*windowed) {
		int i = SDL_GetWindowDisplayIndex(win);
		SDL_SetWindowFullscreen(win, 0);
	} else {
		int i = SDL_GetWindowDisplayIndex(win);
		SDL_Rect j;
		SDL_GetDisplayBounds(i, &j);
		SDL_SetWindowFullscreen(win, 0);
	}
	// recalculateResolution(); // This function sets appropriate font sizes/UI positions
}

// @author: Leopold Schmid
ClientGame::ClientGame() : title("Fish Game Client") {

	int flags = SDL_WINDOW_FULLSCREEN | SDL_WINDOW_RESIZABLE | SDL_WINDOW_SHOWN | SDL_WINDOW_OPENGL;

	if (SDL_Init(SDL_INIT_EVERYTHING) == 0) {
		// log init
		window = SDL_CreateWindow(title, xpos, ypos, SCREEN_WIDTH, SCREEN_HEIGHT, flags);
		if (window) {
			// log window creation
		}

		renderer = SDL_CreateRenderer(window, -1, 0);
		if (renderer) {
			// log renderer created
			SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
		}

		SDL_RenderSetLogicalSize(renderer, SCREEN_WIDTH, SCREEN_HEIGHT);

	} else {
		spdlog::get("stderr")->error("SDL could not initialize! SDL_Error:{}", SDL_GetError());
		isRunning = false;
	}

	// load textures
	assets = new AssetManager(this->getManager());
	assets->addTexture("pistol", "./assets/PistolSmall.png");
	assets->addTexture("projectile", "./assets/ProjectileSmall.png");
	assets->addTexture("present", "./assets/present.png");
}

// @author: Leopold Schmid
ClientGame::~ClientGame() {
	spdlog::get("console")->info(" ============= ClientGame deconstruction ==============");
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	SDL_Quit();
	spdlog::get("console")->info(" ============= ClientGame deconstruction finished ==============");
}

// @author: Fabian Aster
void ClientGame::reset() {
	spdlog::get("console")->info("============ ClientGame - Resetting =============");
	stop();
	networkClient.~NetworkClient();       // Explicitly call the destructor
	new (&networkClient) NetworkClient(); // Placement new to construct a new instance in the same memory location

	hostPlayer = nullptr;
	connected = false;
}

// @author: Leopold Schmid
void ClientGame::init(fs::path mp, bool combat) {
	size_t progressUpdate = 0;
	auto future = std::async(std::launch::async, &FishEngine::ClientGame::startLoadingBar, this);

	isRunning = true;
	hostPlayer = nullptr;

	// ============ control if game was reset ===========
	assert(manager.checkEmpty());

	// ================ init clientMap ==================
	mapPath = mp;
	map = new Map();
	map->loadMap(fs::path("./maps") / mapPath);

	// reset entityGroups
	entityGroups.clear();

	// load assets
	fishSpriteID = 0;
	loadFishSprites();

	// render loading bar and wait for it to finish
	renderLoadingBar();
	future.wait();

	// remove all SDL_Events which occured during loading from the queue
	SDL_PumpEvents();
	SDL_FlushEvents(SDL_FIRSTEVENT, SDL_LASTEVENT);
}

// @author: Leopold Schmid
void ClientGame::loadFishSprites() {
	for (int i = 1; i <= numPlayers; i++) {
		std::string id = "fish0" + std::to_string(i);
		assets->addTexture(id, "./assets/" + id + ".png");
	}
}

// @author: Leopold Schmid
void ClientGame::handleEvents() {
	SDL_PollEvent(&game_event);
	// int eventCount = SDL_PeepEvents(nullptr, 0, SDL_PEEKEVENT, SDL_FIRSTEVENT, SDL_LASTEVENT);

	switch (game_event.type) {
		// case quitting the game
	case SDL_QUIT:
		spdlog::get("console")->info("Leaving game");
		isRunning = false;
		break;
		// case F11 is pressed
	case SDL_KEYDOWN:
		if (game_event.key.keysym.sym == SDLK_F11) {
			toggleWindowMode(window, &windowed);
		}
	default:
		break;
	}
}

// @author: Leopold Schmid
void ClientGame::update() {
	// delete dead entities
	manager.refresh<ClientGame>();

	// // update the entities
	// spdlog::get("console")->debug("Updating entities");
	manager.update();

	// check for collisions
	Collision::isInWater(&manager.getGroup(groupLabels::groupPlayers), map);
	Collision::checkCollisions(&manager.getGroup(groupLabels::groupColliders), map);
	Collision::checkCollisions(&manager.getGroup(groupLabels::groupPlayers),
	                           &manager.getGroup(groupLabels::groupProjectiles));

	manager.refresh<ClientGame>();

	// // animate the map
	map->updateAnimations();

	// check if game is over TODO: just handle it in the server
	if (manager.getGroup(groupLabels::groupPlayers).empty()) {
		spdlog::get("console")->info("Client Game - Game over");
		isRunning = false;
	}
}

// @author: Leopold Schmid
void ClientGame::render() const {
	SDL_RenderClear(renderer);

	map->drawMap();

	for (auto &t : manager.getGroup_c(groupLabels::groupPlayers)) {
		t->draw();
	}

	for (auto &t : manager.getGroup_c(groupLabels::groupWeapons)) {
		t->draw();
	}

	for (auto &t : manager.getGroup_c(groupLabels::groupProjectiles)) {
		t->draw();
	}

	// assets->renderFonts();

	SDL_RenderPresent(renderer);
}

// @author: Leopold Schmid
void ClientGame::createHostPlayer() {
	hostPlayer = &manager.addEntity();
	auto initPos = map->getPlayerSpawnpoints().at(0);
	ClientGenerator::forPlayer(*hostPlayer, initPos, ++fishSpriteID);
	hostPlayerID = hostPlayer->getID();
}

// @author: Leopold Schmid
Manager *ClientGame::getManager() {
	return &manager;
}

// @author: Leopold Schmid
std::string ClientGame::joinInterface() {

	map = new Map();
	map->loadMap(fs::path("./maps/joinLobby.tmj"));

	FontManager gInputTextTexture(renderer, "./assets/zd-bold.ttf");
	FontManager gPromptTextTexture(renderer, "./assets/zd-bold.ttf", 26);

	SDL_Color textColor = {0, 0, 0, 255};
	SDL_Event event;

	// remove all SDL_Events which occured during loading from the queue
	SDL_PumpEvents();
	SDL_FlushEvents(SDL_FIRSTEVENT, SDL_LASTEVENT);
	SDL_StartTextInput();

	std::string inputText = "xxx.xxx.xxx.xxx";
	gInputTextTexture.loadFromRenderedText(inputText.c_str(), textColor);
	gPromptTextTexture.loadFromRenderedText("Enter IP Address", textColor);

	bool modified = false;
	bool running = true;
	bool renderText = true;

	while (running) {
		while (SDL_PollEvent(&event) != 0) {
			switch (event.type) {
			case SDL_KEYDOWN:
				switch (event.key.keysym.sym) {
				// return to main menu
				case SDLK_ESCAPE:
					inputText = "";
					running = false;
					break;
					// delete the last character
				case SDLK_BACKSPACE:
					if (inputText.length() > 0) {
						inputText.pop_back();
						renderText = true;
					}
					break;
				// handle comitting the input
				case SDLK_RETURN:
					// check if the input is a valid IPv4 address
					// if not, show an error message
					if (isValidIPv4(inputText)) {
						running = false;
					} else {
						modified = false;
						renderText = true;
						inputText = "Invalid IP Address";
						gInputTextTexture.loadFromRenderedText(inputText.c_str(), textColor);
					}
					break;
				// handle copy
				case SDLK_c:
					if (SDL_GetModState() & KMOD_CTRL) {
						SDL_SetClipboardText(inputText.c_str());
					}
					break;
				// handle paste
				case SDLK_v:
					if (SDL_GetModState() & KMOD_CTRL) {
						char *tmpText = SDL_GetClipboardText();
						inputText = tmpText;
						SDL_free(tmpText);

						renderText = true;
					}
					break;
				}
				break;
			case SDL_TEXTINPUT:
				if (modified) {
					inputText += event.text.text;
				} else {
					inputText = event.text.text;
					modified = true;
				}
				renderText = true;
				break;
			}
		}
		if (renderText) {
			if (inputText.length() == 0) {
				inputText = " ";
			}
			renderText = false;
			gInputTextTexture.loadFromRenderedText(inputText.c_str(), textColor);
			SDL_SetRenderDrawColor(renderer, 0xFF, 0xFF, 0xFF, 0xFF);
			SDL_RenderClear(renderer);

			map->drawMap();
			gPromptTextTexture.render((SCREEN_WIDTH - gPromptTextTexture.getWidth()) / 2, SCREEN_HEIGHT / 3 + 55);
			gInputTextTexture.render((SCREEN_WIDTH - gInputTextTexture.getWidth()) / 2,
			                         SCREEN_HEIGHT / 3 + 65 + gPromptTextTexture.getHeight());

			SDL_RenderPresent(renderer);
		}
	}

	SDL_StopTextInput();
	stop();
	return inputText;
}

// @author: Fabian Aster
void ClientGame::sendJoinRequest(std::string ip, std::string username) {
	this->networkClient.init(ip, username);
}

// @author: Leopold Schmid, Fabian Aster
void ClientGame::receiveGameState() {

	if (!this->networkClient.hasUpdate()) {
		// spdlog::get("console")->debug("skipped, no update received");
		return;
	}

	std::string serializedData = this->networkClient.getUpdate();
	std::istringstream is(serializedData);
	cereal::BinaryInputArchive ar(is);

	// fetch the number of the entities
	std::unordered_map<uint8_t, groupLabels> new_entityGroups;
	size_t numEntities;
	ar(numEntities);

	// first time while joining clear all entities - TODO: why not in init?
	if (!connected) {
		this->getManager()->destroyEntities<ClientGame>();
		spdlog::get("console")->info("Client Game - Receiving game state with {} players for the first time!",
		                             numEntities);
	}

	// check if the entities are already loaded
	for (size_t i = 0; i < numEntities; ++i) {
		// read entity meta data from stream
		uint8_t id;
		groupLabels group;
		ar(id, group);
		if (entityGroups.count(id)) {
			// case: entity already in manager
			new_entityGroups.insert(std::make_pair(id, group));
			// ...and remove from old list
			entityGroups.erase(id);

			assert(&manager.getEntity(id) != nullptr);
		} else {
			spdlog::get("console")->info("Entity {} of type {} not in manager. Creating now", id,
			                             static_cast<int>(group));

			// create the entity
			auto &entity = manager.addEntity(id);

			// create the entity with the correct components
			switch (group) {
			case groupLabels::groupPlayers:
				// TODO: when joining combat its already connected -> no new eventhandler is created
				if (!connected && i == numEntities - 1) {
					this->hostPlayerID = id;
					ClientGenerator::forPlayer(entity, {0, 0}, ++fishSpriteID);
				} else if (connected && id == this->hostPlayerID) {
					ClientGenerator::forPlayer(entity, {0, 0}, ++fishSpriteID);
				} else {
					ClientGenerator::forEnemy(entity, {0, 0}, ++fishSpriteID);
				}
				break;
			case groupLabels::groupWeapons:
				ClientGenerator::forWeapon(entity, {0, 0});
				break;
			case groupLabels::groupProjectiles:
				ClientGenerator::forProjectile(entity, {0, 0});
				break;
			default:
				throw std::runtime_error("Server is requesting to create an unknown group type.");
				break;
			}

			// add the entity to the manager
			new_entityGroups.insert(std::make_pair(id, group));

			if (i == 0) {
				// moved it down here, so that each player has the host as hostPlayer
				// so that if the host starts the game, all clients will notice the
				// map change
				this->hostPlayer = &entity;
			}
		}

		// update the values of the entity
		assert(&manager.getEntity(id) != nullptr);
		ar(manager.getEntity(id));
	}

	// destroy all entities which are not in the update
	for (auto &entity : entityGroups) {
		manager.getEntity(entity.first).destroy();
	}
	entityGroups = new_entityGroups;

	this->connected = true;
}

void ClientGame::showIP(SDL_Texture *mTexture, int width, int height) {
	int x = 0;
	int y = 0;
	SDL_Rect renderQuad = {(SCREEN_WIDTH - width) / 2, SCREEN_HEIGHT / 3, width, height};

	SDL_RenderCopy(renderer, mTexture, NULL, &renderQuad);
}

// @author: Leopold Schmid
uint8_t ClientGame::updateMainMenu() const {
	if (this->hostPlayer == nullptr) {
		spdlog::get("console")->warn("Client Game - No Player from server assigned yet!");
		return 0;
	}

	if (Collision::checkBack(*hostPlayer, *map))
		return 0;

	if (Collision::checkJoin(*hostPlayer, *map))
		return 1;

	if (Collision::checkHost(*hostPlayer, *map))
		return 2;

	if (Collision::checkStart(*hostPlayer, *map))
		return 3;

	return -1;
}

// @author: Leopold Schmid
bool ClientGame::running() const {
	return isRunning;
}

// @author: Leopold Schmid, Fabian Aster
void ClientGame::stop() {
	spdlog::get("console")->info("=============== stopping ClientGame ===============");
	manager.destroyEntities<ClientGame>();
	entityGroups.clear();
	delete map;
	map = nullptr;
	isRunning = false;
}

// todo: does not work yet - prob pretty wrong
// void ClientGame::zoomIn() {
// 	// Get the most outer players
// 	std::vector<Entity *> &players = manager.getGroup(groupLabels::groupPlayers);
// 	if (players.empty())
// 		return;

// 	int minX = players[0]->getComponent<TransformComponent>().position.getX();
// 	int minY = players[0]->getComponent<TransformComponent>().position.getY();
// 	int maxX = minX, maxY = minY;

// 	for (auto &player : players) {
// 		TransformComponent &transform = player->getComponent<TransformComponent>();
// 		int x = transform.position.getX();
// 		int y = transform.position.getY();
// 		minX = std::min(minX, x);
// 		minY = std::min(minY, y);
// 		maxX = std::max(maxX, x);
// 		maxY = std::max(maxY, y);
// 	}

// 	// int minWidth = std :

// 	minX = std::max(0, minX - 100);
// 	minY = std::max(0, minY - 100);
// 	maxX = std::min(SCREEN_WIDTH, maxX + 100);
// 	maxY = std::min(SCREEN_HEIGHT, maxY + 100);

// 	int width = (maxX - minX);
// 	int height = (maxY - minY);

// 	// create a minimum size for the camera
// 	width = std::max(width, SCREEN_WIDTH);
// 	height = std::max(height, SCREEN_HEIGHT);

// 	camera = {minX, minY, width, height};
// 	camera = {0, 0, SCREEN_WIDTH * 2, SCREEN_HEIGHT};

// 	spdlog::get("console")->debug("Camera: {} {} {} {}", camera.x, camera.y, camera.w, camera.h);
// }

// @author: Leopold Schmid
void ClientGame::startLoadingBar() {
	progressUpdate = 0;
	for (size_t i = 0; i < SCREEN_HEIGHT / 16; ++i) {
		++progressUpdate;
		std::this_thread::sleep_for(std::chrono::milliseconds(20));
	}
}

// @author: Leopold Schmid
void ClientGame::renderLoadingBar() {
	Map *loadingScreen = new Map();
	loadingScreen->loadMap(fs::path("./maps/loadingBar.tmj"), false);

	size_t progressBarsComplete = SCREEN_HEIGHT / 16;

	while (progressUpdate < progressBarsComplete) {
		loadingScreen->drawLoadingBar(progressUpdate);
		loadingScreen->updateAnimations();
		SDL_RenderPresent(ClientGame::renderer);
		SDL_Delay(1);
	}

	delete loadingScreen;
}

void ClientGame::printEntityMetaData() {

	spdlog::get("console")->debug("ClientGame - hostPlayerID: {}", hostPlayerID);
	spdlog::get("console")->debug("ClientGame - entityGroups size: {}", entityGroups.size());
	spdlog::get("console")->debug("ClientGame - entities in manager: {}", manager.getEntities().size());
	spdlog::get("console")->debug("ClientGame - Map path: {}\n\n", mapPath.string());

	for (auto &entity : manager.getEntities()) {
		assert(entityGroups.count(entity.first));
	}
}

} // namespace FishEngine
