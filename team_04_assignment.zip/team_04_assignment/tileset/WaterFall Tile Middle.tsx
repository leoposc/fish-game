<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="WaterFall Tile Middle" tilewidth="16" tileheight="16" tilecount="8" columns="8">
 <image source="AdventureTiles/Animated Tiles/Water/Desaturated - background/PNGs/WaterFall Tile Middle.png" width="128" height="16"/>
</tileset>
