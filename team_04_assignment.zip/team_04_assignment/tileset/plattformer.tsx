<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="generic_platformer_tiles" tilewidth="32" tileheight="32" tilecount="768" columns="32">
 <image source="../../../../Downloads/generic_platformer_tiles.png" width="1024" height="768"/>
</tileset>
