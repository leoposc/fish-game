<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="b73038f9eac5959eeb50ec65377bc460" tilewidth="32" tileheight="32" tilecount="216" columns="18">
 <image source="../../../../Downloads/b73038f9eac5959eeb50ec65377bc460.png" width="576" height="386"/>
</tileset>
