cmake --build --preset conan-debug
cd ./build/Debug/
./fish_game
