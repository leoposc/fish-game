cmake --build --preset conan-debug
./build/Debug//fish_game
